﻿namespace Surge.Messages.Cerebral
{
    public class CatchupMsg
    {
    }
}
