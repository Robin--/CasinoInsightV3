﻿using Akka.Actor;

namespace Surge.Messages.Cerebral
{
    /// <summary>
    /// Instruct the Nuclei to Warmup the Nesper Engine
    /// </summary>
    public class InitializeEngineMsg
    {
    }
}
