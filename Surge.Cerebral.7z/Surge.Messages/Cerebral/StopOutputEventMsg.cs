﻿namespace Surge.Messages.Cerebral
{
    public class StopOutputEventMsg
    {
    }
}
