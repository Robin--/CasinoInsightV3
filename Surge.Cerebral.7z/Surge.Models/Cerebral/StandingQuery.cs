﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Surge.Models.Cerebral
{
    public class StandingQuery
    {
        public string StandingQueryId { get; set; }
        public string Description { get; set; }
        public string EplStatement { get; set; }
    }
}
